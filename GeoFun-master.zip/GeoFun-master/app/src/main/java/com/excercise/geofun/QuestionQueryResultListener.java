package com.excercise.geofun;

public interface QuestionQueryResultListener {

        void onResult(Question question);

}
