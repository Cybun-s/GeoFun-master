package com.excercise.geofun;

public interface CountryQueryResultListener {

    void onResult(Country country);

}
