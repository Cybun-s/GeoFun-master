package com.excercise.geofun;

public interface ScoreQueryResultListener {

    void onResult(Score score);
}
