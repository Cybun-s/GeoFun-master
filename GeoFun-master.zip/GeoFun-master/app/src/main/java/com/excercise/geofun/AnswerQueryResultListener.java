package com.excercise.geofun;

public interface AnswerQueryResultListener {

    void onResult(Answer answer);

}
